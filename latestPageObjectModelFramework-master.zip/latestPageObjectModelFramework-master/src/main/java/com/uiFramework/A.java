package com.uiFramework;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.uiFramework.companyName.bhanuProjectName.testbase.TestBase;

public class A extends TestBase{
	
	@Test
	public void testLoginA(){
		Assert.assertTrue(true);
	}

}
