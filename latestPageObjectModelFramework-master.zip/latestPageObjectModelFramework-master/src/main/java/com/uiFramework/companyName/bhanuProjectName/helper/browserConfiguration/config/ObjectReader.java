package com.uiFramework.companyName.bhanuProjectName.helper.browserConfiguration.config;
/**
 * 
 * @author Bhanu Pratap Singh
 *
 */
public class ObjectReader {

	public static ConfigReader reader;
}
