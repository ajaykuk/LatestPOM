package com.uiFramework.companyName.bhanuProjectName.helper.browserConfiguration;

public enum BrowserType {
	Firefox,
	Iexplorer,
	Chrome
}
