package com.uiFramework.companyName.bhanuProjectName.testScripts.productDetailsPage;

import org.apache.log4j.Logger;

import com.uiFramework.companyName.bhanuProjectName.helper.logger.LoggerHelper;
import com.uiFramework.companyName.bhanuProjectName.testbase.TestBase;


/**
 * @author Bhanu Pratap
 */
public class VerifyColorFilter extends TestBase{
	private final Logger log = LoggerHelper.getLogger(VerifyColorFilter.class);
	
	public void testVerifyColorFilter(){
		
	}

}
