package com.uiFramework.companyName.bhanuProjectName.pageObject;

public class PaymentPage {

}
