package com.uiFramework.companyName.bhanuProjectName.testScripts.productDetailsPage;

import org.testng.annotations.Test;

import com.uiFramework.companyName.bhanuProjectName.testbase.TestBase;

/**
 * @author Bhanu Pratap
 */
public class VerifyInformationLinkText extends TestBase{
	
	@Test
	public void testVerifyInformationLinkText(){
		
	}

}
